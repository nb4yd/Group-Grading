# P5640ex00

The starter code here demonstrates very basic usage of the gsl for solving a problem of coupled differential equations.  Use of an 8th order R-K solver with fixed step size is used.  You are encouraged to try other solvers as you explore the problem.  See here for the gsl docs: https://www.gnu.org/software/gsl/doc/html/ode-initval.html

This example solves the 2D projectile motion problem with a simple model for air resistance.  After each step, data are stored in ROOT TGraphs, which are then displayed at the conclusion of the calculation.  These are the basic peices you will need to address the Duffing Oscillator problem.

See the description of this exercise in the assifned reading and on the course web site.

Give the computing IDs for team members here:  dag5jr  agg4hc 

Push your solution code and PDF reports to this repo.
