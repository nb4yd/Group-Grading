#include "TROOT.h"
#include "TApplication.h"
#include "TFile.h"
#include "TGraph.h"
#include "TCanvas.h"
#include "TGClient.h"
#include "TH2F.h"
#include "TStyle.h"
#include "TF1.h"
#include "TRandom3.h"
#include <gsl/gsl_spmatrix.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <iostream>
using std::cout;
using std::endl;
using std::vector;

const int occupied= 1;
const int incr= 200;

//Structure for storing coordinates of lattice site
typedef struct {
  int x, y;
} site;

//Get a vector containing all boundary sites
vector<site> getBoundary(int dim[]) {
  vector<site> boundary(0);
  for(int i=0; i<dim[1]; i++) {
    site s1;
    s1.x=0;
    s1.y=i;

    site s2;
    s2.x= dim[0]-1;
    s2.y=i;

    boundary.push_back(s1);
    boundary.push_back(s2);
  }

  for(int j=1; j<dim[0]-1; j++) {
    site s1;
    s1.x=j;
    s1.y=0;

    site s2;
    s2.x=j;
    s2.y= dim[1]-1;

    boundary.push_back(s1);
    boundary.push_back(s2);
  }

  return boundary;
}

//Get randome element from a given vector;
site getRandElem(vector<site> boundary, TRandom3 *rgen) {
  double r= rgen->Rndm();
  int i= floor(r*boundary.size());
  return boundary[i];
}

//Returns all possible adjacent sites (not accounting for boundaries)
vector<site> adjSites(site s, int dim[]) {
  vector<site> sites(0);

  site adj;
  if(s.x>0) {
    adj.x=s.x-1;
    adj.y=s.y;
    sites.push_back(adj);
  }

  if(s.x<dim[0]-1) {
    adj.x=s.x+1;
    adj.y=s.y;
    sites.push_back(adj);
  }

  if(s.y>0) {
    adj.x=s.x;
    adj.y=s.y-1;
    sites.push_back(adj);
  }

  if(s.y<dim[1]-1) {
    adj.x=s.x;
    adj.y=s.y+1;
    sites.push_back(adj);
  }

  return sites;
}

//Moves site in a random direction if allowed
site move(site s, int dim[], TRandom3 *rgen) {
  vector<site> sites= adjSites(s, dim);
  return getRandElem(sites, rgen);
}

//Determine if a site has any neighbors
bool isNotAdj(gsl_spmatrix *lat, site s, int dim[]) {
  site adjSite;
  vector<site> adj= adjSites(s, dim);
  for(unsigned int i=0; i<adj.size(); i++) {
    adjSite= adj[i];
    if(gsl_spmatrix_get(lat, adjSite.x, adjSite.y) != 0) return false;
  }

  return true;
} 

int main(int argc, char **argv) {
  //check for command line arguments
  if (argc<3) {
    cout << "Must Provide: n (int specifying lat lenght), m (int specifying lat width, and size (int specifying # of lat sites)" << endl;
    return 0;
  }

  TApplication theApp("App", &argc, argv); // init ROOT App for displays
  UInt_t dh = gClient->GetDisplayHeight()/2;    
  UInt_t dw = 2*dh;
  TStyle *style= new TStyle("style", "DLA Style");
  style->SetOptStat(false);
  gROOT->SetStyle("style");

  //assign command line arguments
  TRandom3 *rgen= new TRandom3(0);
  int n= atoi(argv[1]);
  int m= atoi(argv[2]);
  int size= atoi(argv[3]);
  int dim[2]= {n, m};

  //ensure lattice is big enough
  if(0.5*n*m<=size) {
    cout << "Lattice is to small for desired cluster size.\n" << endl;
    return 0;
  }

  //create sparse matrix with one site a the center
  gsl_spmatrix *lattice= gsl_spmatrix_alloc(n, m);
  int n0= round(n/2);
  int m0= round(n/2);
  // printf("%d %d\n", n0, m0);
  gsl_spmatrix_set(lattice, n0, m0, occupied);


  //variables for calculating Rg
  int points= floor(size/incr);
  double x[points]; double y[points];
  double r_i= 0; //sum of |r_i|^2
  double r0_x= 0; //mean x radius
  double r0_y= 0; //mean y radius
  int N=1;
  int count=1;
  int ind=0;
  double Rg;
  
  vector<site> boundary= getBoundary(dim);

  //add sites to create dendritic cluster
  for (int i=0; i<size-1; i++) {
    site newSite= getRandElem(boundary, rgen);
    //printf("%d %d\n", newSite.x, newSite.y);
    while(isNotAdj(lattice, newSite, dim)) {
      newSite= move(newSite, dim, rgen);
      //printf("%d %d\n", newSite.x, newSite.y);
    }
    //add site to occupancy matrix
    gsl_spmatrix_set(lattice, newSite.x, newSite.y, occupied);

    //track r0 and r_i for every new site
    r_i += (newSite.x-n0)*(newSite.x-n0) + (newSite.y-m0)*(newSite.y-m0);
    r0_x += newSite.x-n0;
    r0_y += newSite.y-m0;
    N++;
    count++;
    //calculate Rg every n sites
    if(count>=incr) {
      count=0;
      Rg= sqrt(r_i/N - (r0_x*r0_x+r0_y*r0_y)/N/N);
      y[ind]= log(N);
      x[ind]= log(Rg);
      ind++;
    }
  }


  //create picture of cluster
  TCanvas *tc = new TCanvas("c","DLA",dw,dh);
  TH2F *graph= new TH2F("dla", "DLA Simulation;x;y",dim[0],0,dim[0],dim[1],0,dim[1]);
  for(int i=0; i<dim[0]; i++) {
    for(int j=0; j<dim[1]; j++) {
      graph->Fill(i+0.5,j+0.5, gsl_spmatrix_get(lattice,i,j));
    }
  }

  //make graph of fractal order
  TGraph *plot= new TGraph(points, x, y);
  plot->SetTitle("Fractal Dimension");
  plot->GetXaxis()->SetTitle("Log(N)");
  plot->GetYaxis()->SetTitle("Log(Rg)");
  plot->SetMarkerStyle(21);
  plot->SetMarkerColor(4);
  plot->Fit("pol1");

  tc->Divide(2,1);
  tc->cd(1);
  graph->Draw("BOX A");
  tc->cd(2);
  plot->Draw();
  tc->Update();

  // save plots
  TFile *tf=new TFile("DLA.root","recreate");
  graph->Write();
  tf->Close();

  cout << "Press ^c to exit" << endl;
  theApp.SetIdleTimer(30,".q");  // set up a failsafe timer to end the program  
  theApp.Run();
  return 1;
}


