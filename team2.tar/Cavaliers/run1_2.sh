#!/bin/bash

DLA 300 300 9000
